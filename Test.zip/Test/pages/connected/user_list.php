<?php
    if(get_user_data($_SESSION['user'])['role'] == 'basic_user') {
        print '<h1>You don\'t have access to this section</h1>';
        return;
    }
?>

<h1>User list</h1>

<br/>

<form method="post">
    Search product <input type="text" name="kwu" placeholder="Search by keyword..."/>
    <input type="submit" name="search" value="Search"/>
    <input type="submit" name="resetu" value="Reset search"/>
</form>

<br/>

<?php
    if(isset($_POST['kwu'])) {
        $keyword = $_POST['kwu'];
        $users = get_users_by_keyword($keyword);
        setcookie('keyword_user', $keyword, time()+24*60*60);
    } else if(isset ($_COOKIE['keyword_user'])) {
        $keyword = $_COOKIE['keyword_user'];
        $users = get_users_by_keyword($keyword);
    } else {
        $users = get_users();
    }
    
    if(isset($_POST['resetu'])) {
        $users = get_users();
        setcookie('keyword_user', '', time()-1);
    }

?>
<table class="table table-striped">
    <tr>
        <th>Profile_picture</th>
        <th>Role</th>
        <th>Email</th>
        <th>First_name</th>
        <th>Last_name</th>
        <th></th>
    </tr>
<?php
    foreach ($users as $user) {
?>
    <tr>
        <td>
            <img src="images/<?php 
            $user_image = $user['profile_picture'];
            $image_exist = file_exists("images/".$user_image);
                if($user_image != NULL && $image_exist) {
                    print $user_image;
                } else {
                    print "default.jpg";
                }
                    ?>" width="50px"/>
        </td>
        <td><?php print $user['role'] ?></td>
        <td><?php print $user['email'] ?></td>
        <td><?php print $user['first_name'] ?></td>
        <td><?php print $user['last_name'] ?></td>
        <?php if($user['email'] != $_SESSION['user']) { ?>
        <td>
            <a href="index.php?page=5&delete=<?php print $user['id'] ?>">Delete</a>
            <?php if($user['role'] == 'basic_user') { ?>
            <a href="index.php?page=5&make_admin=<?php print $user['id'] ?>">Make admin</a>
            <?php } ?>
        </td>
        <?php } ?>
    </tr>
<?php
        }
?>
</table>

<?php
    if(isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $delete_result = delete_user_by_id($id);
        if($delete_result) {
            header('location: index.php?page=5');
        } else {
            print "An error occurred during user deletion";
        }
    }
    
    if(isset($_GET['make_admin'])) {
        $id = $_GET['make_admin'];
        $make_result = make_user_admin($id);
        if($make_result) {
            header('location: index.php?page=5');
        } else {
            print "An error occurred during the making of admin";
        }
    }
?>