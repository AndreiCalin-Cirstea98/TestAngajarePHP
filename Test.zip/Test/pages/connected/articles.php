<h1>Articles</h1>

<br/>

<form method="post">
    Search product: <input type="text" name="kw" placeholder="Search by keyword..."/>
    <input type="submit" name="search" value="Search"/>
    <input type="submit" name="reset" value="Reset search"/>
</form>

<br/>

<?php
    if(isset($_POST['kw'])) {
        $keyword = $_POST['kw'];
        $products = get_products_by_keyword($keyword);
        setcookie('keyword', $keyword, time()+24*60*60);
    } else if(isset ($_COOKIE['keyword'])) {
        $keyword = $_COOKIE['keyword'];
        $products = get_products_by_keyword($keyword);
    } else {
        $products = get_products();
    }
    
    if(isset($_POST['reset'])) {
        $products = get_products();
        setcookie('keyword', '', time()-1);
    }
    
    if(count($products) == 0) {
        print "There are no products in stock";
    } else {
?>
<table class="table table-striped">
    <tr>
        <th>SKU</th>
        <th>Item name</th>
        <th>Description</th>
        <th>Price</th>
    </tr>
<?php
    foreach ($products as $product) {
?>
    <tr>
        <td><?php print $product['sku'] ?></td>
        <td><?php print $product['item_name'] ?></td>
        <td><?php print $product['description'] ?></td>
        <td><?php print $product['price'] ?> €</td>
        <td>
            <?php if(get_user_data($_SESSION['user'])['role'] == 'basic_user') { ?>
            <a href="index.php?page=2&product_id=<?php print $product['id'] ?>">Add in cart</a>
            <?php }?>
            <?php if(get_user_data($_SESSION['user'])['role'] == 'admin') { ?>
            <a href="index.php?page=2&edit=<?php print $product['id'] ?>">Edit</a>
            <a href="index.php?page=2&delete=<?php print $product['id'] ?>">Delete</a>
            <?php }?>
        </td>
    </tr>
<?php
        }
    }
?>
</table>

<?php
    if(isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $delete_result = delete_product_by_id($id);
        
        if($delete_result) {
            if(isset($_SESSION['cart'][$id])) {
                unset($_SESSION['cart'][$id]);
            }
            $_SESSION['deleted_products'] = 'Some products are no longer available,'
                    . ' they have been removed automatically from the cart.';
            header('location: index.php?page=2');
        }
    }
    
    if(isset($_GET['edit'])) {
        require_once 'pages/connected/edit_article.php';
    }
?>