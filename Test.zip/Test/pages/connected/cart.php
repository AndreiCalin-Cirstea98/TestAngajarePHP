<?php
    if(get_user_data($_SESSION['user'])['role'] == 'admin') {
        print '<h1>You don\'t have access to this section</h1>';
        return;
    }
?>

<h1>Cart</h1>

<br/>

<?php
    if(isset($_SESSION['deleted_products'])) {
        print '<h2 style="color: green">'.$_SESSION['deleted_products'].'</h2>';
        unset($_SESSION['deleted_products']);
    }
    
    if(!empty($_SESSION['cart'])) {
?>
<table class="table table-striped">
    <tr>
        <th>SKU</th>
        <th>Item name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Quantity</th>
        <th></th>
    </tr>

<?php
    $total = 0;
    foreach ($_SESSION['cart'] as $id_product => $quantity){
        $product = get_product_by_id($id_product);
        if (empty($product)) {
            continue;
        }
        $total += $quantity * $product['price'];
        ?>
    <tr>
        <td><?php print $product['sku'] ?></td>
        <td><?php print $product['item_name'] ?></td>
        <td><?php print $product['description'] ?></td>
        <td><?php print $product['price'] ?></td>
        <td><?php print $quantity ?></td>
        <td><a href="index.php?page=3&remove_id=<?php print $id_product ?>">Remove</a></td>
    </tr>
<?php
    }
    print "</table><br/>";
?>
    <div class="btn btn-default">
<?php
    print "Total price: $total €";
?>
    </div>
<?php
    } else {
?>
    <div class="btn btn-default">
<?php
        print "Your cart is empty";
?>
    </div>
<?php
    }
?>
