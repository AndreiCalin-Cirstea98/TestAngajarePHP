<?php
    $user_image = get_user_data($_SESSION['user'])['profile_picture'];
    $image_exist = file_exists("images/".$user_image);
    
    if($user_image != NULL && $image_exist) {
        $image_adress = $user_image;
    } else {
        $image_adress = "default.jpg";
    }
?>

<h1>Profile</h1>

<br/>

<div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item"><img width="100px" src="images/<?php print $image_adress; ?> "></li>
        <li class="list-group-item"><p>First name: <?php print get_user_data($_SESSION['user'])['first_name']; ?></p></li>
        <li class="list-group-item"><p>Last name: <?php print get_user_data($_SESSION['user'])['last_name']; ?></p></li>
        <li class="list-group-item"><p>Email: <?php print $_SESSION['user']; ?></p></li>
        <li class="list-group-item"><p>Security question: <?php print get_user_data($_SESSION['user'])['question']; ?></p></li>
        <li class="list-group-item"><p>Security answer: <?php print get_user_data($_SESSION['user'])['answer']; ?></p></li>
    </ul>
</div>
<form method="post" enctype="multipart/form-data" class="form-inline">
    <div class="form-group">
        <label for="file_search">Update profile picture:</label>
        <input type="file" name="profile_picture" id="file_search" class="form-control-file" id="exampleFormControlFile1"/>
    </div>
    <div class="form-group">
        <input type="submit" name="add_image" value="Upload image" class="btn btn-default"/>
    </div>
</form>

<?php
    require_once 'functions/sql_functions.php';
    
    $phpFileUploadErrors = array(
    0 => 'There is no error, the file uploaded with success',
    1 => 'The uploaded file exceeds the upload_max_filesize directive in php.ini',
    2 => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form',
    3 => 'The uploaded file was only partially uploaded',
    4 => 'No file was uploaded',
    6 => 'Missing a temporary folder',
    7 => 'Failed to write file to disk.',
    8 => 'A PHP extension stopped the file upload.',
    );
    
    if(isset($_POST['add_image'])) {
        if($_FILES['profile_picture']['error'] == 0) {
            switch ($_FILES['profile_picture']['type']) {
                case 'image/jpg':
                case 'image/jpeg':
                case 'image/png':
                case 'image/bmp':
                case 'image/gif':
                    $unique_image_name = uniqid().$_FILES['profile_picture']['name'];
                    $server_save = move_uploaded_file($_FILES['profile_picture']['tmp_name'], 'images/'.$unique_image_name);
                    
                    if($server_save) {
                        $db_save = add_image($unique_image_name, $_SESSION['user']);
                        
                        if($db_save) {
                            header('location: index.php');
                        } else {
                            unlink('images/'.$unique_image_name);
                            print "An error occurred during database save";
                        }
                    } else {
                        print "An error occurred during server save";
                    }
                    break;
            }
        } else {
            if($_FILES['profile_picture']['error'] == 4) {
                return;
            } else {
                print "An error occurred".$phpFileUploadErrors[$_FILES['profile_picture']['error']];
            }
        }
    }
?>