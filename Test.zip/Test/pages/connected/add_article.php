<?php
    if(get_user_data($_SESSION['user'])['role'] == 'basic_user') {
        print '<h1>You don\'t have access to this section</h1>';
        return;
    }
?>

<h1>Add article</h1>

<br/>

<form method="post" class="form-horizontal">
    <table>
        <tr>
            <td>SKU:</td>
            <td><input type="text" name="sku" minlength="5" required/></td>
        </tr>
        <tr>
            <td>Item name:</td>
            <td><input type="text" name="item_name" minlength="3" required/></td>
        </tr>
        <tr>
            <td>Description:</td>
            <td><textarea type="text" name="description" minlength="10" required></textarea></td>
        </tr>
        <tr>
            <td>Price(€):</td>
            <td><input type="number" name="price" min="1" required/></td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="add" value="Add product"/>
            </td>
        </tr>
    </table>
</form>

<?php
    if(isset($_POST['add'])) {
        $sku = $_POST['sku'];
        $item_name = $_POST['item_name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        
        $result_add_product = add_product($sku, $item_name,
                                          $description, $price);
        if($result_add_product) {
            header('location: index.php?page=2');
        } else {
            print "An error occurred during database save";
        }
    }
?>