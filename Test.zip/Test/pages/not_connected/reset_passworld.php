<h1>Reset password</h1>

<form method="post" class="form-horizontal">
    <table>
        <tr>
            <td>Email:</td>
            <td>
                <input type="email" name="email" minlength="3" required>
            </td>
        </tr>
        <tr>
            <td>New passworld:</td>
            <td>
                <input type="password" name="pass" minlength="5" required>
            </td>
        </tr>
        <tr>
            <td><label for="q">Select your security question:</label></td>
            <td>
                <select name="question" id="q" required>
                    <option value="q1">Question 1</option>
                    <option value="q2">Question 2</option>
                    <option value="q3">Question 3</option>
                    <option value="q4">Question 4</option>
                    <option value="q5">Question 5</option>
                    <option value="q6">Question 6</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Answer the selected question:</td>
            <td>
                <input type="text" name="answer" required>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="reset" value="Reset" class="btn btn-default">
            </td>
        </tr>
    </table>
</form>

<?php
    require_once 'functions/sql_functions.php';
    
    if(isset($_POST['reset'])) {
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        
        $result = reset_pass($email, $pass, $question, $answer);
        if($result) {
            print "Password reseted successfully";
        } else {
            print "Password couldn't be resetted";
        }
    }