<h1>Register</h1>

<form method="post" class="form-horizontal">
    <table>
        <tr>
            <td>First name:</td>
            <td>
                <input type="text" name="first_name" minlength="2" required>
            </td>
        </tr>
        <tr>
            <td>Last name:</td>
            <td>
                <input type="text" name="last_name" minlength="2" required>
            </td>
        </tr>
        <tr>
            <td>Email:</td>
            <td>
                <input type="email" name="email" minlength="3" required>
            </td>
        </tr>
        <tr>
            <td>Passworld:</td>
            <td>
                <input type="password" name="pass" minlength="5" required>
            </td>
        </tr>
        <tr>
            <td><label for="q">Select a security question:</label></td>
            <td>
                <select name="question" id="q" required>
                    <option value="q1">Question 1</option>
                    <option value="q2">Question 2</option>
                    <option value="q3">Question 3</option>
                    <option value="q4">Question 4</option>
                    <option value="q5">Question 5</option>
                    <option value="q6">Question 6</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Answer the selected question:</td>
            <td>
                <input type="text" name="answer" required>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="register" value="Register" class="btn btn-default">
            </td>
        </tr>
    </table>
</form>

<?php 
    require_once 'functions/sql_functions.php';
    
    if(isset($_POST['register'])) {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            print $email."is not a valid email address";
        } else {
            $r = sign_up($first_name, $last_name, $email, $pass, $question, $answer);
            if($r) {
                $_SESSION['user'] = $email;
                $_SESSION['welcome'] = 'Your account was successfully created';
                header('location: index.php');
            } else {
                print '<div style="color: red">An error occurred</div>';
            }
        }
    }
?>