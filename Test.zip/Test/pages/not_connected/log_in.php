<h1>Log in</h1>

<form method="post" class="form-horizontal">
    <table>
        <tr>
            <td>Email:</td>
            <td>
                <input type="email" name="email" required>
            </td>
        </tr>
        <tr>
            <td>Passworld:</td>
            <td>
                <input type="password" name="pass" required>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="login" value="Login" class="btn btn-default">
            </td>
        </tr>
    </table>
</form>

<?php 
    if(isset($_SESSION['login_error'])) {
        print '<div style="color: red">'.$_SESSION['login_error'].'</div>';
    }
    
    if(isset($_SESSION['invalid_email'])) {
        print '<div style="color: red">'.$_SESSION['invalid_email'].'</div>';
    }
    
    if(isset($_GET['page'])) {
        $page = $_GET['page'];
        
        if($page == 'reset_pass'){
            require_once 'pages/not_connected/reset_passworld.php';
        }
    }
?>