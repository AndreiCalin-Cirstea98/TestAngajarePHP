<?php
    require_once 'functions/sql_functions.php';
    
    session_start();
    
    if(isset($_POST['login'])){
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['invalid_email'] = $email."is not a valid email address";
        } else {
            $connection_result = connect($email, $pass);
            if($connection_result) {
                if(isset($_SESSION['login_error'])) {
                    unset($_SESSION['login_error']);
                }
                if(isset($_SESSION['invalid_email'])) {
                    unset($_SESSION['invalid_email']);
                }
                $_SESSION['user'] = $email;
            } else {
                $_SESSION['login_error'] = 'Failed login';
            }
        }
    }
    
    if (isset($_GET['product_id'])) {
        $id = $_GET['product_id'];
        if(isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]++;
        } else {
            $_SESSION['cart'][$id] = 1;
        }
        header('location: index.php?page=2');
    }
    
    if(isset($_GET['remove_id'])) {
        $id = $_GET['remove_id'];
        if($_SESSION['cart'][$id] > 1) {
            $_SESSION['cart'][$id]--;
        } else {
            unset($_SESSION['cart'][$id]);
        }
        header('location: index.php?page=3');
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/style_Q.css"/>
    </head>
    <body>
        <header class="panel panel-primary"></header>
        <?php
            if(isset($_SESSION['user'])) {
                require_once 'templates/template_connected.php';
            } else {
                require_once 'templates/template_not_connected.php';
            }
        ?>
    </body>
</html>

