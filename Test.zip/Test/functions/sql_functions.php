<?php

    function connect_to_db ($host = 'localhost',
                           $user = 'root',
                           $pass = '',
                           $dbname = 'test')
    {
        return mysqli_connect($host, $user, $pass, $dbname);
    }
    
    function clear_data ($input, $link) {
        $link = connect_to_db();
        $input = trim($input);
        $input = htmlspecialchars($input);
        $input = stripcslashes($input);
        $input = mysqli_real_escape_string($link, $input);
        
        return $input;
    }
    
    function check_user_by_email ($email) {
        $link = connect_to_db();
        $email = clear_data($email, $link);
        $query = "SELECT * from user WHERE email='$email'";
        
        $user = mysqli_query($link, $query);
        $user_array = mysqli_fetch_array($user, MYSQLI_ASSOC);
        return $user_array;
    }
    
    function sign_up ($first_name, $last_name, $email,
                      $pass, $question, $answer)
    {
        $link = connect_to_db();
        $first_name = clear_data($first_name, $link);
        $last_name = clear_data($last_name, $link);
        $email = clear_data($email, $link);
        $pass = clear_data($pass, $link);
        $pass = md5($pass);
        $question = clear_data($question, $link);
        $answer = clear_data($answer, $link);
        
        $user = check_user_by_email($email);
        if($user) {
            return false;
        }
        
        $query = "INSERT INTO user"
                . "(first_name,last_name,email,"
                . "pass,question,answer) VALUES "
                . "('$first_name','$last_name','$email',"
                . "'$pass','$question','$answer')";
        return mysqli_query($link, $query);
    }
    
    function connect($email, $pass) {
        $link = connect_to_db();
        $email = clear_data($email, $link);
        $pass = clear_data($pass, $link);
        
        $user = check_user_by_email($email);
        if($user) {
            return md5($pass) == $user['pass'];
        } else {
            return false;
        }
    }
    
    function get_user_data($email) {
        $link = connect_to_db();
        $query = "SELECT role, first_name, last_name,"
                . " profile_picture, question, answer"
                . " FROM user WHERE email='$email'";
        $data = mysqli_query($link, $query);
        $data_array = mysqli_fetch_array($data, MYSQLI_ASSOC);
        
        return $data_array;
    }
    
    function reset_pass($email,$pass, $question, $answer) {
        $link = connect_to_db();
        $email = clear_data($email, $link);
        $pass = clear_data($pass, $link);
        $pass = md5($pass);
        $question = clear_data($question, $link);
        $answer = clear_data($answer, $link);
        
        if(get_user_data($email)['question'] == $question &&
           get_user_data($email)['answer'] == $answer) {
            $query = "UPDATE user SET pass='$pass'"
                . " WHERE email='$email'";
            return mysqli_query($link, $query);
        } 
    }
    
    function add_image($image_name, $email) {
        $link = connect_to_db();
        $image_name = clear_data($image_name, $link);
        $query = "UPDATE user SET profile_picture='$image_name'"
                . " WHERE email='$email'";
        return mysqli_query($link, $query);
    }
    
    function add_product($sku, $item_name, $description, $price) {
        $link = connect_to_db();
        $sku = clear_data($sku, $link);
        $item_name = clear_data($item_name, $link);
        $description = clear_data($description, $link);
        $price = clear_data($price, $link);
        
        $query = "INSERT INTO articles VALUES"
                . " (NULL, '$sku', '$item_name', '$description', '$price')";
        return mysqli_query($link, $query);
    }
    
    function get_products() {
        $link = connect_to_db();
        $query = "SELECT * FROM articles";
        
        $products = mysqli_query($link, $query);
        $products_array = mysqli_fetch_all($products, MYSQLI_ASSOC);
        
        return $products_array;
    }
    
    function get_product_by_id($id) {
        $link = connect_to_db();
        $id = clear_data($id, $link);
        $query = "SELECT * FROM articles WHERE id ='$id'";
        
        $product = mysqli_query($link, $query);
        $product_array = mysqli_fetch_array($product, MYSQLI_ASSOC);
        return $product_array;
    }
    
    function delete_product_by_id($id) {
        $link = connect_to_db();
        $id = clear_data($id, $link);
        $query = "DELETE FROM articles WHERE id =$id";
        return mysqli_query($link, $query);
    }
    
    function edit_product($id, $sku, $item_name, $description, $price) {
        $link = connect_to_db();
        $id = clear_data($id, $link);
        $sku = clear_data($sku, $link);
        $item_name = clear_data($item_name, $link);
        $description = clear_data($description, $link);
        $price = clear_data($price, $link);
        
        $query = "UPDATE articles SET sku='$sku',"
                . "item_name='$item_name', description='$description',"
                . "price='$price' WHERE id='$id'";
        return mysqli_query($link, $query);
    }
    
    function get_products_by_keyword($keyword) {
        $link = connect_to_db();
        $keyword = clear_data($keyword, $link);
        $query = "SELECT * FROM articles WHERE sku LIKE '%$keyword%'"
                . " OR item_name LIKE '%$keyword%'"
                . " OR description LIKE '%$keyword%'";
        
        $products = mysqli_query($link, $query);
        $products_array = mysqli_fetch_all($products, MYSQLI_ASSOC);
        return $products_array;
    }
    
    function get_users() {
        $link = connect_to_db();
        $query = "SELECT * FROM user";
        
        $users = mysqli_query($link, $query);
        $users_array = mysqli_fetch_all($users, MYSQLI_ASSOC);
        return $users_array;
    }
    
    function delete_user_by_id($id) {
        $link = connect_to_db();
        $id = clear_data($id, $link);
        $query = "DELETE FROM user WHERE id ='$id'";
        return mysqli_query($link, $query);
    }
    
    function make_user_admin($id) {
        $link = connect_to_db();
        $id = clear_data($id, $link);
        $query = "UPDATE user SET role='admin' WHERE id='$id'";
        return mysqli_query($link, $query);
    }
    
    function get_users_by_keyword($keyword) {
        $link = connect_to_db();
        $keyword = clear_data($keyword, $link);
        $query = "SELECT * FROM user WHERE role LIKE '%$keyword%'"
                . " OR first_name LIKE '%$keyword%'"
                . " OR last_name LIKE '%$keyword%'"
                . " OR email LIKE '%$keyword%'";
        
        $users = mysqli_query($link, $query);
        $users_array = mysqli_fetch_all($users, MYSQLI_ASSOC);
        return $users_array;
    }