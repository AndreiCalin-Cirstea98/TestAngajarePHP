<nav class="col-sm-3 sidenav">
    <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php">Profile</a></li>
        <li><a href="index.php?page=2">Articles</a></li>
        <?php if(get_user_data($_SESSION['user'])['role'] == 'basic_user') { ?>
        <li><a href="index.php?page=3">Cart</a></li>
        <?php }?>
        <?php
        $user_role = get_user_data($_SESSION['user'])['role'];
        if($user_role == 'admin') { ?>
            <li><a href="index.php?page=4">Add article</a></li>
            <li><a href="index.php?page=5">User list</a></li>
        <?php
        }
        ?>
        <li><a href="index.php?logout">Logout, <?php print$_SESSION['user'] ?></a></li>
    </ul>
</nav>

<section class="col-sm-9">
    <?php
        if(isset($_GET['logout'])) {
            session_destroy();
            header('location: index.php');
        }
        
        if(isset($_SESSION['welcome'])){
            print $_SESSION['welcome'];
            unset($_SESSION['welcome']);
        }
        
        if(isset($_GET['page'])){
            $page = $_GET['page'];
            
            if ($page == 2) {
                require_once 'pages/connected/articles.php';
            } else if($page == 3){
                require_once 'pages/connected/cart.php';
            }else if($page == 4) {
                require_once 'pages/connected/add_article.php';
            } else if($page == 5) {
                require_once 'pages/connected/user_list.php';
            }
        } else {
            require_once 'pages/connected/profile.php';
        }
    ?>
</section>