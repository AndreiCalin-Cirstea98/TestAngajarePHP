<nav class="col-sm-3 sidenav">
    <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php">Sign in</a></li>
        <li><a href="index.php?page=1">Sign up</a></li>
        <li><a href="index.php?reset_pass">Did you forget your passorld?</a></li>
    </ul>
</nav>

<section class="col-sm-9">
    <?php
        if(isset($_GET['page'])) {
            $page = $_GET['page'];
            if($page == 1) {
                require_once 'pages/not_connected/register.php';
            } else {
                require_once 'pages/error.php';
            }
        } else if(isset($_GET['reset_pass'])) {
            require_once 'pages/not_connected/reset_passworld.php';
        } else {
            require_once 'pages/not_connected/log_in.php';
        }
    ?>
</section>